# LoveProject
A simple static webpage as a gift for my girlfriend . Although a personal project , but made it open-source to help all the lovers out there who are seeking for a creative idea to impress their partners.
<br>
You can check this out with 

<br>
Link: https://ritvikbhatia.github.io/LoveProject
